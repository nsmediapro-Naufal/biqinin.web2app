# Bagawi

## Cara Membangun Aplikasi (Otomatis via GitHub Actions)

Sistem ini telah dilengkapi dengan konfigurasi **GitHub Actions** untuk mem-build aplikasi Anda secara otomatis di cloud (tanpa perlu menginstal Android Studio atau Xcode di komputer Anda).

### Langkah-langkah:
1. Buat repository baru di [GitHub](https://github.com/new) (bisa Public atau Private).
2. Upload/Push semua file yang ada di dalam folder ZIP ini ke repository GitHub Anda.
3. Buka tab **Actions** di repository GitHub Anda.
4. GitHub akan otomatis mendeteksi file konfigurasi dan mulai mem-build aplikasi Anda.
5. Tunggu sekitar 3-5 menit. Setelah proses selesai (ceklis hijau), klik pada workflow tersebut.
6. Scroll ke bagian bawah (Artifacts), Anda akan menemukan file **APK** atau **App** yang siap didownload dan diinstal!

*Catatan: Ini adalah source code dasar. Untuk aplikasi produksi, Anda mungkin perlu menambahkan Keystore (untuk Android) atau Certificate (untuk iOS).*
